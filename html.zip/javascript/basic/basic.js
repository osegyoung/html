// basic.js

let myName = "user01"; // string 변수선언.
let myAge = 20; // number 변수 20 값을 대입.
let myObj = {name: "user02", age: 25}; // object 변수.

console.log(myName == "user01");
console.log(myAge == myName);

console.log("내 이름은 " + myObj.name + "입니다."); // "user02"
console.log(myObj.age + 3); // 25