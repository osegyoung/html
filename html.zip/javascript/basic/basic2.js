// basic2.js

let anyVal = prompt("값을 입력하세요: ");
let anyVal2 = prompt("값을 입력하세요: ");

let result = Number(anyVal) + parseInt(anyVal2);
console.log(`두수의 합은 ${result} 입니다.`);